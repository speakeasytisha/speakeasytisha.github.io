(() => {
  const stateKey = 'mounia-flight-b2-lesson1';
  const appState = JSON.parse(localStorage.getItem(stateKey) || '{}');
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const toast = (msg) => { const t=$('#toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),1800); };
  const saveState = () => localStorage.setItem(stateKey, JSON.stringify(appState));

  // ---------- Data ----------
  const translationQuestions = [
    {q:'You want to say: « Je gère les situations difficiles. »', options:['I manage difficult situations.','I handle difficult situations.','I manage with difficult situations.'], answer:1, explain:'“Handle” is the natural verb for dealing with a difficult situation.', hint:'Think: deal with / handle — not a word-for-word translation of gérer.'},
    {q:'You want to say: « Je suis habituée à travailler sous pression. »', options:['I am used to working under pressure.','I have the habit to work under pressure.','I am used to work under pressure.'], answer:0, explain:'After “be used to”, use a noun or -ing form.', hint:'be used to + noun / verb-ing'},
    {q:'You want to say: « Je passe un entretien demain. »', options:['I pass an interview tomorrow.','I have an interview tomorrow.','I make an interview tomorrow.'], answer:1, explain:'In English, you “have an interview”.', hint:'You have an appointment; you also have an interview.'},
    {q:'You want to say: « Je suis d’accord. »', options:['I am agree.','I agree.','I am agreeing.'], answer:1, explain:'“Agree” is a verb: I agree.', hint:'No “be” before the verb agree.'},
    {q:'You want to say: « Je vais vérifier pour vous. »', options:['I will control for you.','I’m going to verify you.','Let me check that for you.'], answer:2, explain:'“Let me check that for you” is natural and service-oriented.', hint:'A customer-service chunk beginning with “Let me…”'},
    {q:'You want to say: « Il faut trouver une solution. »', options:['We need to find a solution.','It is necessary to find a solution.','We must search a solution.'], answer:0, explain:'“We need to find a solution” is direct and natural in professional English.', hint:'Use need to + find.'},
    {q:'You want to say: « Je vais vous expliquer la procédure. »', options:['I explain you the procedure.','I’ll explain the procedure to you.','I’ll explain you how is the procedure.'], answer:1, explain:'Explain something to someone.', hint:'explain + thing + to + person'},
    {q:'You want to say: « Je veux m’assurer que vous avez compris. »', options:['I want to assure that you understood.','I want to make sure you understood.','I want to be sure if you understanded.'], answer:1, explain:'“Make sure” is the natural chunk here.', hint:'make sure + clause'}
  ];

  const grammarQuestions = [
    {q:'I am ___ qualified cabin crew member.', options:['a','the','—'], answer:0, explain:'Use “a” when naming a profession or role.', hint:'One role, mentioned generally.'},
    {q:'I worked ___ the airport for one year.', options:['at','on','in'], answer:0, explain:'Use “at the airport” for the location/workplace.', hint:'at = point/location'},
    {q:'The passenger left a passport ___ the aircraft.', options:['at','on','to'], answer:1, explain:'We say “on the aircraft / on the plane / on the flight”.', hint:'Transport surface/context → on.'},
    {q:'Please go to ___ gate shown on your boarding pass.', options:['a','the','—'], answer:1, explain:'The gate is specific: the one shown on the boarding pass.', hint:'Specific/identified noun.'},
    {q:'She is waiting ___ the terminal.', options:['at','in','on'], answer:1, explain:'Use “in the terminal” when inside the building.', hint:'Inside an enclosed place.'},
    {q:'We need ___ solution that works for the passenger.', options:['a','the','—'], answer:0, explain:'First mention of one non-specific solution → “a”.', hint:'One possible solution, not identified yet.'},
    {q:'I spoke to ___ passenger who reported the missing bag.', options:['a','the','—'], answer:1, explain:'This passenger is identified by the relative clause/context.', hint:'A specific passenger already identifiable.'},
    {q:'There was ___ problem with the baggage system.', options:['a','the','—'], answer:0, explain:'First mention of one countable problem → “a”.', hint:'One problem, introduced for the first time.'},
    {q:'The customer is ___ Gate 12.', options:['at','in','on'], answer:0, explain:'Use “at Gate 12” for a specific point/location.', hint:'Gate number = point.'},
    {q:'There are several passengers ___ the boarding area.', options:['at','in','on'], answer:1, explain:'Use “in the boarding area”.', hint:'Within an area → in.'}
  ];


  const grammarLabCategories = [{"name": "Present Simple vs Present Continuous", "questions": [{"q": "I usually ___ passenger complaints at the service desk.", "options": ["handle", "am handling", "have handled"], "answer": 0, "explain": "Use Present Simple for routines and regular responsibilities.", "hint": "Usually is a strong signal for Present Simple."}, {"q": "Please wait a moment. I ___ your booking now.", "options": ["check", "am checking", "have checked"], "answer": 1, "explain": "Use Present Continuous for an action happening now.", "hint": "The word now points to an action in progress."}, {"q": "Our team ___ special-assistance requests every day.", "options": ["is coordinating", "coordinates", "has coordinated"], "answer": 1, "explain": "Use Present Simple for repeated work processes.", "hint": "Every day = routine."}]}, {"name": "Past Simple vs Present Perfect", "questions": [{"q": "I ___ as an airport agent in 2024.", "options": ["have worked", "worked", "have been working"], "answer": 1, "explain": "Use Past Simple with a finished, specific past time.", "hint": "A finished year such as 2024 normally takes Past Simple."}, {"q": "I ___ several difficult passenger situations during my career.", "options": ["handled", "have handled", "am handling"], "answer": 1, "explain": "Use Present Perfect for life/work experience when no finished time is given.", "hint": "No specific finished date; the experience is relevant now."}, {"q": "She ___ the incident report yesterday.", "options": ["has completed", "completed", "completes"], "answer": 1, "explain": "Yesterday requires Past Simple.", "hint": "Finished past-time marker = Past Simple."}]}, {"name": "Present Perfect details", "questions": [{"q": "I have worked in aviation ___ three years.", "options": ["since", "for", "during"], "answer": 1, "explain": "Use for + a duration.", "hint": "Three years is a length of time."}, {"q": "The passenger hasn’t received the bag ___ .", "options": ["already", "yet", "ever"], "answer": 1, "explain": "Use yet in negatives and questions for something expected up to now.", "hint": "Negative sentence + expected result."}, {"q": "Have you ___ dealt with a medical emergency?", "options": ["ever", "since", "yet"], "answer": 0, "explain": "Use ever to ask about experience at any time up to now.", "hint": "Experience question = ever."}]}, {"name": "Future forms", "questions": [{"q": "I ___ check the latest flight information for you.", "options": ["am going", "will", "am"], "answer": 1, "explain": "Will is natural for a decision/offer made at the moment of speaking.", "hint": "A spontaneous service offer often uses will."}, {"q": "We ___ the recruiter tomorrow at 10 a.m.", "options": ["meet", "are meeting", "will meeting"], "answer": 1, "explain": "Present Continuous is common for a fixed personal arrangement.", "hint": "A scheduled arrangement already organised."}, {"q": "Look at those queues. Boarding ___ take longer than expected.", "options": ["is going to", "will to", "is"], "answer": 0, "explain": "Be going to is used for a prediction based on present evidence.", "hint": "You can see evidence now."}]}, {"name": "Modals: ability, advice, obligation", "questions": [{"q": "Passengers ___ show a valid boarding pass before entering this area.", "options": ["must", "could", "might"], "answer": 0, "explain": "Must expresses a strong rule or obligation.", "hint": "This is a requirement, not a suggestion."}, {"q": "You ___ speak to the baggage desk if you need a written report.", "options": ["should", "mustn’t", "can’t"], "answer": 0, "explain": "Should gives advice or a recommended next step.", "hint": "Recommendation = should."}, {"q": "___ you tell me what happened first, please?", "options": ["Could", "Must", "Should to"], "answer": 0, "explain": "Could makes a polite professional request.", "hint": "Polite request to a passenger."}]}, {"name": "Questions & auxiliaries", "questions": [{"q": "How long ___ you worked in aviation?", "options": ["did", "have", "are"], "answer": 1, "explain": "Present Perfect question: How long have you worked…?", "hint": "Experience continuing to now → have."}, {"q": "___ the passenger report the bag yesterday?", "options": ["Has", "Did", "Does"], "answer": 1, "explain": "Use did for a Past Simple question.", "hint": "Yesterday = Past Simple; question auxiliary = did."}, {"q": "What ___ you do if a passenger became aggressive?", "options": ["would", "do", "are"], "answer": 0, "explain": "Use would in a hypothetical interview question.", "hint": "If + past form often pairs with would in the result/question."}]}, {"name": "Articles", "questions": [{"q": "She is ___ experienced airport agent.", "options": ["a", "an", "the"], "answer": 1, "explain": "Use an before a vowel sound: an experienced agent.", "hint": "Listen to the first sound of experienced."}, {"q": "Please return to ___ gate on your boarding pass.", "options": ["a", "the", "—"], "answer": 1, "explain": "The gate is specific and identified by the boarding pass.", "hint": "Specific/identified noun = the."}, {"q": "___ safety is our first priority.", "options": ["A", "The", "—"], "answer": 2, "explain": "Abstract/general nouns often take no article when used generally.", "hint": "Safety here is a general concept."}]}, {"name": "Prepositions", "questions": [{"q": "The passenger is waiting ___ Gate 18.", "options": ["at", "in", "on"], "answer": 0, "explain": "Use at for a precise point such as a numbered gate.", "hint": "Gate number = point."}, {"q": "I left my notebook ___ the aircraft.", "options": ["at", "on", "to"], "answer": 1, "explain": "Use on with aircraft/plane/flight.", "hint": "Transport context = on."}, {"q": "The family is waiting ___ the terminal.", "options": ["in", "at", "on"], "answer": 0, "explain": "Use in when inside an enclosed building/area.", "hint": "Inside the terminal."}]}, {"name": "Countable / uncountable & quantifiers", "questions": [{"q": "How ___ luggage does the passenger have?", "options": ["many", "much", "few"], "answer": 1, "explain": "Luggage is uncountable, so use much.", "hint": "You cannot normally say one luggage/two luggages."}, {"q": "There are only ___ seats left on the flight.", "options": ["a little", "a few", "much"], "answer": 1, "explain": "Seats are countable plural, so use a few.", "hint": "Countable plural → few/a few."}, {"q": "We have ___ information about the delay at the moment.", "options": ["a few", "many", "little"], "answer": 2, "explain": "Information is uncountable; little means not much.", "hint": "Information is uncountable."}]}, {"name": "Comparatives & superlatives", "questions": [{"q": "This solution is ___ than asking the passenger to wait for another hour.", "options": ["more efficient", "efficienter", "most efficient"], "answer": 0, "explain": "Use more + adjective for longer adjectives such as efficient.", "hint": "Long adjective → more + adjective."}, {"q": "That was the ___ situation I handled that week.", "options": ["more stressful", "most stressful", "stressfullest"], "answer": 1, "explain": "Use the + superlative for the highest degree in a group/time period.", "hint": "The + most + adjective."}, {"q": "The new process is slightly ___ than the old one.", "options": ["clearer", "clearest", "more clear than"], "answer": 0, "explain": "Clear commonly forms the comparative with -er: clearer.", "hint": "Short adjective → -er is natural."}]}, {"name": "Conditionals", "questions": [{"q": "If the flight ___ delayed, we’ll inform passengers immediately.", "options": ["is", "will be", "was"], "answer": 0, "explain": "First conditional: if + Present Simple, will + base verb.", "hint": "Do not normally put will after if in a first conditional."}, {"q": "If I ___ in that situation, I would speak to the supervisor first.", "options": ["am", "were", "will be"], "answer": 1, "explain": "Second conditional commonly uses were for hypothetical situations.", "hint": "Hypothetical interview answer → If I were…"}, {"q": "If a passenger needs assistance, I ___ the request before boarding.", "options": ["would confirm", "confirm", "will confirmed"], "answer": 1, "explain": "For a general procedure/routine, use Present Simple in both clauses (zero conditional idea).", "hint": "General rule/process, not one future event."}]}, {"name": "Gerund vs infinitive", "questions": [{"q": "I am used to ___ under pressure.", "options": ["work", "working", "to work"], "answer": 1, "explain": "Be used to + noun or -ing form.", "hint": "Here to is a preposition, not an infinitive marker."}, {"q": "We need ___ the passenger before the gate closes.", "options": ["contact", "to contact", "contacting"], "answer": 1, "explain": "Need is followed by to + infinitive.", "hint": "need to + base verb."}, {"q": "Try to avoid ___ with an angry passenger.", "options": ["argue", "to argue", "arguing"], "answer": 2, "explain": "Avoid is followed by the -ing form.", "hint": "avoid + verb-ing."}]}, {"name": "Relative clauses", "questions": [{"q": "The passenger ___ reported the bag is waiting outside.", "options": ["who", "which", "where"], "answer": 0, "explain": "Use who for people.", "hint": "Passenger = person."}, {"q": "The suitcase ___ was left at security has been found.", "options": ["who", "that", "where"], "answer": 1, "explain": "Use that/which for things.", "hint": "Suitcase = thing."}, {"q": "This is the desk ___ passengers report missing baggage.", "options": ["who", "where", "which person"], "answer": 1, "explain": "Use where for a place in which an action happens.", "hint": "Desk/location → where."}]}, {"name": "Passive voice", "questions": [{"q": "Your bag ___ and will be delivered to your hotel.", "options": ["has located", "has been located", "was locate"], "answer": 1, "explain": "Present Perfect passive: has/have been + past participle.", "hint": "The bag receives the action."}, {"q": "The flight ___ by 40 minutes because of weather conditions.", "options": ["has been delayed", "has delayed", "is delaying"], "answer": 0, "explain": "Use the passive because the flight receives the delay action.", "hint": "has been + past participle."}, {"q": "Passengers ___ to remain near the gate.", "options": ["have asked", "have been asked", "are ask"], "answer": 1, "explain": "Present Perfect passive: have been asked.", "hint": "Passengers receive the instruction."}]}, {"name": "French interference & natural English", "questions": [{"q": "Choose the natural English: « J’assiste à une réunion demain. »", "options": ["I assist a meeting tomorrow.", "I’m attending a meeting tomorrow.", "I attend to a meeting tomorrow."], "answer": 1, "explain": "Attend means be present at a meeting. Assist means help someone.", "hint": "French assister ≠ English assist in this context."}, {"q": "Choose the natural English: « Je vais vous expliquer la situation. »", "options": ["I’ll explain you the situation.", "I’ll explain the situation to you.", "I’ll explain to you about the situation."], "answer": 1, "explain": "Explain something to someone.", "hint": "Thing first, then to + person."}, {"q": "Choose the natural English: « Je cherche une solution. »", "options": ["I’m searching a solution.", "I’m looking for a solution.", "I’m researching for a solution."], "answer": 1, "explain": "Look for is the natural everyday/professional phrase for trying to find something.", "hint": "chercher → look for, not search + object in this context."}]}];

  const vocab = [
    {title:'Conflict & de-escalation', icon:'🧯', rows:[
      ['to de-escalate','désamorcer','We need to de-escalate the situation before it becomes more stressful.'],
      ['to acknowledge a concern','reconnaître une inquiétude','Start by acknowledging the passenger’s concern.'],
      ['to remain calm','rester calme','I remain calm even when the passenger is upset.'],
      ['to set a clear boundary','poser une limite claire','We can be polite while setting a clear boundary.'],
      ['to reach a solution','aboutir à une solution','Let’s see if we can reach a solution together.']
    ]},
    {title:'Baggage & airport operations', icon:'🧳', rows:[
      ['baggage allowance','franchise bagage','Let me check the baggage allowance on your booking.'],
      ['oversized baggage','bagage hors gabarit','Oversized baggage may need to be checked in.'],
      ['delayed baggage','bagage retardé','The passenger has reported delayed baggage.'],
      ['baggage tracing','traçage des bagages','I’ll check the baggage tracing status.'],
      ['overhead locker / bin','compartiment à bagages','Your bag needs to fit in the overhead locker.']
    ]},
    {title:'Stress & crisis language', icon:'🚨', rows:[
      ['to assess the situation','évaluer la situation','First, I would assess the situation and identify the immediate risk.'],
      ['to prioritise','prioriser','We need to prioritise safety and urgent passenger needs.'],
      ['to follow procedure','suivre la procédure','I would remain calm and follow the appropriate procedure.'],
      ['to keep someone informed','tenir quelqu’un informé','I’ll keep you informed as soon as I have confirmed information.'],
      ['to escalate the issue','faire remonter le problème','If necessary, I would escalate the issue to a supervisor.']
    ]},
    {title:'Special assistance & passenger needs', icon:'♿', rows:[
      ['special assistance','assistance particulière','Let me confirm the special assistance request.'],
      ['reduced mobility','mobilité réduite','The passenger has reduced mobility and needs support at the gate.'],
      ['to accommodate a need','répondre à un besoin','We will do our best to accommodate the passenger’s needs.'],
      ['medical requirement','besoin médical','Is there any medical requirement we should be aware of?'],
      ['to make arrangements','prendre des dispositions','I’ll make the necessary arrangements with the ground team.']
    ]},
    {title:'Diplomatic solution language', icon:'🤝', rows:[
      ['What I can do is…','Ce que je peux faire, c’est…','What I can do is check the next available option.'],
      ['Let me look into that.','Je vais vérifier cela.','Let me look into that and see what happened.'],
      ['Here are the options available.','Voici les options possibles.','Here are the options available at the moment.'],
      ['Just to make sure I understood…','Juste pour vérifier que j’ai bien compris…','Just to make sure I understood, you need assistance for your mother as well.'],
      ['Would that work for you?','Est-ce que cela vous conviendrait ?','I can request a new seat. Would that work for you?']
    ]}
  ];

  const dialectRows = [
    ['hand luggage','carry-on bag','Cabin baggage carried by the passenger'],
    ['overhead locker','overhead bin','Storage above the seats'],
    ['queue','line','People waiting'],
    ['timetable','schedule','Planned times'],
    ['single / return ticket','one-way / round-trip ticket','Ticket type'],
    ['holiday','vacation','Time away from work'],
    ['ground floor','first floor','Floor numbering differs — important!']
  ];

  const assistanceQuestions = [
    {q:'Which reply is safest and most professional?', options:['Don’t worry. You will definitely make the connection.','I can’t promise the connection yet, but I can check the latest information and the assistance arrangements.','You need to speak to someone else.'], answer:1, explain:'B2 professional language reassures without making an unverified promise.', hint:'Avoid guarantees when you do not have confirmed information.'},
    {q:'Which question best clarifies the assistance need?', options:['Why is your mother in a wheelchair?','Has wheelchair assistance already been booked for your mother?','Is your mother old?'], answer:1, explain:'It gathers operationally useful information in a respectful way.', hint:'Ask what you need to act, not unnecessary personal details.'},
    {q:'Which phrase checks understanding naturally?', options:['You understand me?','Is it clear or not?','Just to make sure, you need assistance at arrival and for the connection, correct?'], answer:2, explain:'It reformulates the need and invites confirmation.', hint:'Use “Just to make sure…” + a concise reformulation.'}
  ];

  const lilateInteraction = [
    {q:'Choose the best first question.', options:['Why did you put medication in your bag?','Can you tell me what medication you need and whether you have any with you now?','You should wait until tomorrow.'], answer:1, explain:'Clarify the urgent need first, then check baggage tracing and escalation options.', hint:'Gather the information that affects urgency and next action.'}
  ];

  // ---------- Quiz rendering ----------
  function renderQuiz(containerId, data, keyPrefix){
    const c=$(containerId); if(!c) return;
    c.innerHTML=data.map((item,i)=>`<div class="quiz-item" data-quiz="${keyPrefix}-${i}"><div class="quiz-q">${i+1}. ${item.q}</div><div class="quiz-options">${item.options.map((o,j)=>`<button class="quiz-option" type="button" data-opt="${j}">${o}</button>`).join('')}</div><div class="quiz-feedback"></div><button class="hint-btn practice-only" type="button">Hint</button><div class="hint-text practice-only">${item.hint}</div></div>`).join('');
    $$('.quiz-item',c).forEach((el,i)=>{
      const saved=appState[`${keyPrefix}-${i}`];
      if(Number.isInteger(saved)) markQuiz(el,data[i],saved,true);
      $$('.quiz-option',el).forEach(btn=>btn.addEventListener('click',()=>{
        const choice=Number(btn.dataset.opt); appState[`${keyPrefix}-${i}`]=choice; saveState(); markQuiz(el,data[i],choice,false);
      }));
      const hb=$('.hint-btn',el); if(hb) hb.addEventListener('click',()=>$('.hint-text',el).classList.toggle('show'));
    });
  }
  function markQuiz(el,item,choice,silent){
    el.classList.remove('correct','incorrect'); $$('.quiz-option',el).forEach((b,j)=>b.classList.toggle('selected',j===choice));
    const ok=choice===item.answer; el.classList.add(ok?'correct':'incorrect'); $('.quiz-feedback',el).innerHTML=ok?`<strong>✓ Correct.</strong> ${item.explain}`:`<strong>Not yet.</strong> ${item.explain}`;
    if(!silent) toast(ok?'Correct — nice precision.':'Good try — check the explanation.');
  }
  renderQuiz('#translationQuiz',translationQuestions,'trans');
  renderQuiz('#grammarQuiz',grammarQuestions,'gram');
  renderQuiz('#assistanceQuiz',assistanceQuestions,'assist');
  renderQuiz('#lilateInteractionQuiz',lilateInteraction,'lilateInteract');


  // ---------- B2 Grammar Test Lab ----------
  let grammarLabMode = appState.grammarLabMode || 'practice';
  const flatGrammarLab = grammarLabCategories.flatMap((cat, categoryIndex)=>cat.questions.map((q, questionIndex)=>({...q, category:cat.name, categoryIndex, questionIndex})));

  function grammarLabKey(catIndex,qIndex){ return `glab-${catIndex}-${qIndex}`; }

  function renderGrammarLab(){
    const c=$('#grammarLab'); if(!c) return;
    c.innerHTML=grammarLabCategories.map((cat,ci)=>`
      <section class="grammar-category" data-category="${ci}">
        <div class="grammar-category-head"><div><span class="category-number">${String(ci+1).padStart(2,'0')}</span><h4>${cat.name}</h4></div><span class="category-live-score" id="glabLive-${ci}">— / 3</span></div>
        <div class="quiz-stack grammar-category-questions">
          ${cat.questions.map((item,qi)=>`<div class="quiz-item grammar-lab-item" data-glab="${ci}-${qi}">
            <div class="quiz-q">${qi+1}. ${item.q}</div>
            <div class="quiz-options">${item.options.map((o,oi)=>`<button class="quiz-option" type="button" data-opt="${oi}">${o}</button>`).join('')}</div>
            <div class="quiz-feedback"></div>
            <button class="hint-btn grammar-lab-hint" type="button">Hint</button>
            <div class="hint-text">${item.hint}</div>
          </div>`).join('')}
        </div>
      </section>`).join('');

    $$('.grammar-lab-item',c).forEach(el=>{
      const [ci,qi]=el.dataset.glab.split('-').map(Number);
      const item=grammarLabCategories[ci].questions[qi];
      const key=grammarLabKey(ci,qi);
      const saved=appState[key];
      if(Number.isInteger(saved)) paintGrammarSelection(el,saved);
      if(grammarLabMode==='practice' && Number.isInteger(saved)) revealGrammarFeedback(el,item,saved,true);
      $$('.quiz-option',el).forEach(btn=>btn.addEventListener('click',()=>{
        const choice=Number(btn.dataset.opt);
        appState[key]=choice; saveState(); paintGrammarSelection(el,choice);
        if(grammarLabMode==='practice') revealGrammarFeedback(el,item,choice,false);
        else { el.classList.remove('correct','incorrect'); $('.quiz-feedback',el).textContent='Answer recorded.'; }
        updateGrammarLiveScores();
      }));
      $('.grammar-lab-hint',el)?.addEventListener('click',()=>$('.hint-text',el).classList.toggle('show'));
    });
    applyGrammarLabMode();
    updateGrammarLiveScores();
  }

  function paintGrammarSelection(el,choice){
    $$('.quiz-option',el).forEach((b,j)=>b.classList.toggle('selected',j===choice));
  }

  function revealGrammarFeedback(el,item,choice,silent=false){
    const ok=choice===item.answer;
    el.classList.remove('correct','incorrect'); el.classList.add(ok?'correct':'incorrect');
    $('.quiz-feedback',el).innerHTML=ok?`<strong>✓ Correct.</strong> ${item.explain}`:`<strong>Not yet.</strong> ${item.explain}`;
    if(!silent) toast(ok?'Correct — B2 precision.':'Review the rule, then try again.');
  }

  function applyGrammarLabMode(){
    const practice=grammarLabMode==='practice';
    $('#grammarPracticeBtn')?.classList.toggle('active',practice);
    $('#grammarTestBtn')?.classList.toggle('active',!practice);
    $('#grammar-lab')?.classList.toggle('grammar-test-mode',!practice);
    if($('#grammarLabStatus')) $('#grammarLabStatus').textContent=practice?'Practice mode: corrections appear immediately.':'Test mode: answers are recorded silently. Submit when you are ready.';
    $$('.grammar-lab-item').forEach(el=>{
      const [ci,qi]=el.dataset.glab.split('-').map(Number); const key=grammarLabKey(ci,qi); const choice=appState[key];
      el.classList.remove('correct','incorrect');
      if(practice && Number.isInteger(choice)) revealGrammarFeedback(el,grammarLabCategories[ci].questions[qi],choice,true);
      else if(!practice && Number.isInteger(choice)) $('.quiz-feedback',el).textContent='Answer recorded.';
      else $('.quiz-feedback',el).textContent='';
    });
    updateGrammarLiveScores();
  }

  function updateGrammarLiveScores(){
    grammarLabCategories.forEach((cat,ci)=>{
      let answered=0,correct=0;
      cat.questions.forEach((q,qi)=>{const v=appState[grammarLabKey(ci,qi)];if(Number.isInteger(v)){answered++;if(v===q.answer)correct++;}});
      const el=$(`#glabLive-${ci}`); if(el) el.textContent=grammarLabMode==='practice'?`${correct} / 3`:`${answered} / 3 answered`;
    });
  }

  function grammarLabScores(){
    return grammarLabCategories.map((cat,ci)=>{
      let correct=0, answered=0;
      cat.questions.forEach((q,qi)=>{const v=appState[grammarLabKey(ci,qi)];if(Number.isInteger(v)){answered++;if(v===q.answer)correct++;}});
      return {name:cat.name,correct,answered,total:cat.questions.length};
    });
  }

  function showGrammarResults(revealAnswers=true){
    const scores=grammarLabScores(); const totalCorrect=scores.reduce((s,x)=>s+x.correct,0); const totalAnswered=scores.reduce((s,x)=>s+x.answered,0);
    const result=$('#grammarLabResults'); if(!result) return;
    result.hidden=false;
    $('#grammarTotalScore').textContent=`${totalCorrect} / ${flatGrammarLab.length}`;
    const pct=Math.round(totalCorrect/flatGrammarLab.length*100);
    const msg = totalAnswered<flatGrammarLab.length ? `You answered ${totalAnswered}/${flatGrammarLab.length}. Complete the remaining questions for a full diagnostic.` : pct>=85 ? 'Strong B2 grammar profile. Focus on the few categories below 3/3.' : pct>=70 ? 'Good B1+/B2 pathway. Review the categories marked as priorities before the recruitment test.' : 'The diagnostic has found useful priorities. Work category by category, then retest.';
    $('#grammarResultMessage').textContent=msg;
    $('#grammarCategoryScores').innerHTML=scores.map(s=>{const cls=s.correct===3?'score-strong':s.correct===2?'score-watch':'score-priority';return `<div class="category-score ${cls}"><span>${s.name}</span><strong>${s.correct}/${s.total}</strong><small>${s.answered}/${s.total} answered</small></div>`;}).join('');
    if(revealAnswers){
      $$('.grammar-lab-item').forEach(el=>{const [ci,qi]=el.dataset.glab.split('-').map(Number);const v=appState[grammarLabKey(ci,qi)];if(Number.isInteger(v)) revealGrammarFeedback(el,grammarLabCategories[ci].questions[qi],v,true);});
    }
    appState.grammarLabSubmitted=true; saveState();
    result.scrollIntoView({behavior:'smooth',block:'nearest'});
  }

  $('#grammarPracticeBtn')?.addEventListener('click',()=>{grammarLabMode='practice';appState.grammarLabMode=grammarLabMode;saveState();applyGrammarLabMode();});
  $('#grammarTestBtn')?.addEventListener('click',()=>{grammarLabMode='test';appState.grammarLabMode=grammarLabMode;saveState();applyGrammarLabMode();});
  $('#submitGrammarTestBtn')?.addEventListener('click',()=>showGrammarResults(true));
  $('#resetGrammarLabBtn')?.addEventListener('click',()=>{if(confirm('Reset all 45 grammar diagnostic answers?')){grammarLabCategories.forEach((cat,ci)=>cat.questions.forEach((q,qi)=>delete appState[grammarLabKey(ci,qi)]));delete appState.grammarLabSubmitted;saveState();$('#grammarLabResults').hidden=true;renderGrammarLab();toast('Grammar lab reset.');}});
  renderGrammarLab();
  if(appState.grammarLabSubmitted) showGrammarResults(false);

  // ---------- Vocabulary ----------
  const vacc=$('#vocabAccordion');
  if(vacc){ vacc.innerHTML=vocab.map((cat,i)=>`<div class="accordion-item"><button class="accordion-head" type="button"><span>${cat.icon} ${cat.title}</span><span>＋</span></button><div class="accordion-body">${cat.rows.map(r=>`<div class="vocab-row"><div class="vocab-term">${r[0]}</div><div class="vocab-fr">${r[1]}</div><div class="vocab-example">${r[2]}</div><button class="audio-btn" type="button" data-speak="${r[0]}. ${r[2].replace(/"/g,'&quot;')}">🔊</button></div>`).join('')}</div></div>`).join('');
    $$('.accordion-head',vacc).forEach(b=>b.addEventListener('click',()=>{const item=b.closest('.accordion-item'); item.classList.toggle('open'); b.lastElementChild.textContent=item.classList.contains('open')?'−':'＋';}));
  }

  const dtable=$('#dialectTable'); if(dtable) dtable.innerHTML=`<div class="dialect-row head"><div>🇬🇧 UK</div><div>🇺🇸 US</div><div>Meaning</div></div>`+dialectRows.map(r=>`<div class="dialect-row"><div>${r[0]}</div><div>${r[1]}</div><div>${r[2]}</div></div>`).join('');

  // ---------- Audio ----------
  function speak(text,lang='en-GB'){
    if(!('speechSynthesis' in window)){toast('Audio is not supported in this browser.');return;}
    speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(text); u.lang=lang; u.rate=.94;
    const voices=speechSynthesis.getVoices(); const v=voices.find(x=>x.lang?.toLowerCase().startsWith(lang.toLowerCase())) || voices.find(x=>x.lang?.toLowerCase().startsWith(lang.slice(0,2).toLowerCase())); if(v) u.voice=v; speechSynthesis.speak(u);
  }
  document.addEventListener('click',e=>{ const b=e.target.closest('[data-speak]'); if(b) speak(b.dataset.speak,b.dataset.lang||'en-GB'); });

  // ---------- Response builder ----------
  const builderData={
    ack:['','I understand your concern.','I can see why this is frustrating.','I understand this is stressful.'],
    clarify:['','Let me check exactly what happened.','Just to make sure I understood correctly…','Can I confirm a few details first?'],
    explain:['','Here is what I can see at the moment.','The information I have right now is…','According to the current information…'],
    offer:['','What I can do is check the available options.','Let me see what I can arrange for you.','I can explain the next steps and help you from here.'],
    check:['','Would that work for you?','Does that answer your question?','Is there anything else you need me to clarify?']
  };
  [['ackSelect','ack'],['clarifySelect','clarify'],['explainSelect','explain'],['offerSelect','offer'],['checkSelect','check']].forEach(([id,k])=>{const s=$('#'+id); if(!s)return; s.innerHTML=builderData[k].map((v,i)=>`<option value="${i}">${v||'Choose…'}</option>`).join(''); s.addEventListener('change',updateBuilder);});
  function updateBuilder(){const ids=['ackSelect','clarifySelect','explainSelect','offerSelect','checkSelect'];const keys=['ack','clarify','explain','offer','check'];const txt=ids.map((id,i)=>builderData[keys[i]][Number($('#'+id).value)]||'').filter(Boolean).join(' '); $('#builderOutput').textContent=txt||'Your response will appear here.'; appState.builder=ids.map(id=>$('#'+id).value);saveState();}
  if(appState.builder){['ackSelect','clarifySelect','explainSelect','offerSelect','checkSelect'].forEach((id,i)=>{if($('#'+id)) $('#'+id).value=appState.builder[i]||'0';}); updateBuilder();}
  $('#clearBuilderBtn')?.addEventListener('click',()=>{['ackSelect','clarifySelect','explainSelect','offerSelect','checkSelect'].forEach(id=>$('#'+id).value='0');updateBuilder();});
  $('#speakBuilderBtn')?.addEventListener('click',()=>speak($('#builderOutput').textContent));

  // ---------- Choice cards ----------
  const baggageChoices=[
    ['A','“Calm down. The rules are the rules.”','bad','Too direct and likely to escalate the conflict.'],
    ['B','“I understand why you’re frustrated. Let me check the allowance on your booking first.”','good','Strong opening: acknowledge + clarify before explaining.'],
    ['C','“You have to pay because your bag is too big.”','bad','Fact-focused but not diplomatic and no attempt to clarify or help.']
  ];
  const bc=$('#baggageChoice'); if(bc) bc.innerHTML=baggageChoices.map(x=>`<div class="choice-card ${x[2]==='good'?'good-choice':'bad-choice'}"><div class="choice-letter">${x[0]}</div><div><b>${x[1]}</b><p class="tiny">${x[3]}</p></div><div class="choice-eval ${x[2]}">${x[2]==='good'?'USE':'AVOID'}</div></div>`).join('');

  // ---------- Model tabs ----------
  $$('.model-tab').forEach(tab=>tab.addEventListener('click',()=>{const wrap=tab.closest('.model-switcher');$$('.model-tab',wrap).forEach(x=>x.classList.remove('active'));$$('.model-content',wrap).forEach(x=>x.classList.remove('active'));tab.classList.add('active');$('#'+tab.dataset.target).classList.add('active');}));

  // ---------- Timers ----------
  $$('.timer-widget').forEach(widget=>{
    const initial=Number(widget.dataset.timer||60); let remaining=initial, interval=null; const display=$('.timer-value',widget);
    const fmt=s=>`${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`; display.textContent=fmt(remaining);
    $('.timer-start',widget)?.addEventListener('click',()=>{if(interval)return; interval=setInterval(()=>{remaining--;display.textContent=fmt(Math.max(remaining,0));if(remaining<=0){clearInterval(interval);interval=null;toast('Time. Finish your sentence and stop.');}},1000);});
    $('.timer-reset',widget)?.addEventListener('click',()=>{clearInterval(interval);interval=null;remaining=initial;display.textContent=fmt(remaining);});
  });

  // ---------- Recording ----------
  $$('.recorder').forEach(rec=>{
    let mediaRecorder=null,chunks=[],stream=null;
    const rbtn=$('.record-btn',rec), sbtn=$('.stop-btn',rec), status=$('.record-status',rec), audio=$('.record-playback',rec);
    rbtn?.addEventListener('click',async()=>{
      try{stream=await navigator.mediaDevices.getUserMedia({audio:true});mediaRecorder=new MediaRecorder(stream);chunks=[];mediaRecorder.ondataavailable=e=>chunks.push(e.data);mediaRecorder.onstop=()=>{const blob=new Blob(chunks,{type:mediaRecorder.mimeType||'audio/webm'});audio.src=URL.createObjectURL(blob);audio.hidden=false;stream.getTracks().forEach(t=>t.stop());status.textContent='Recording saved in this page';};mediaRecorder.start();rec.classList.add('recording');status.textContent='Recording…';rbtn.disabled=true;sbtn.disabled=false;}
      catch(e){toast('Microphone access was not available.');status.textContent='Microphone unavailable';}
    });
    sbtn?.addEventListener('click',()=>{if(mediaRecorder&&mediaRecorder.state!=='inactive')mediaRecorder.stop();rec.classList.remove('recording');rbtn.disabled=false;sbtn.disabled=true;});
  });

  // ---------- Save learner fields ----------
  $$('.save-field').forEach(el=>{if(appState.fields?.[el.id]!==undefined) el.value=appState.fields[el.id]; const ev=el.type==='range'?'input':'input';el.addEventListener(ev,()=>{appState.fields=appState.fields||{};appState.fields[el.id]=el.value;saveState();updateWordCounts();});});
  $$('.save-check').forEach((el,i)=>{const k='check-'+i;if(appState[k]!==undefined)el.checked=appState[k];el.addEventListener('change',()=>{appState[k]=el.checked;saveState();});});

  function countWords(v){return v.trim()?v.trim().split(/\s+/).length:0;}
  function updateWordCounts(){if($('#lilateWriting'))$('#lilateWordCount').textContent=countWords($('#lilateWriting').value);if($('#writingTask'))$('#writingWordCount').textContent=countWords($('#writingTask').value);}
  updateWordCounts();

  // ---------- Open answer keyword check ----------
  $$('.check-open-answer').forEach(btn=>btn.addEventListener('click',()=>{const value=$('#'+btn.dataset.target).value.toLowerCase();const keys=btn.dataset.keywords.split(',').map(x=>x.trim().toLowerCase());const hits=keys.filter(k=>value.includes(k.toLowerCase()));const fb=$('#'+btn.dataset.target+'Feedback');fb.innerHTML=`You included <strong>${hits.length}/${keys.length}</strong> key elements. Look for: destination, delay length, passenger instruction and next update time.`;fb.style.color=hits.length>=3?'var(--good)':'var(--warn)';}));

  // ---------- Mode ----------
  function setMode(mode){appState.mode=mode;saveState();document.body.classList.toggle('exam-mode',mode==='exam');$('#practiceModeBtn').classList.toggle('active',mode==='practice');$('#examModeBtn').classList.toggle('active',mode==='exam');$('#modeHelp').textContent=mode==='practice'?'Practice mode shows hints and models.':'Exam mode hides hints, models and trainer tools.';}
  $('#practiceModeBtn')?.addEventListener('click',()=>setMode('practice'));$('#examModeBtn')?.addEventListener('click',()=>setMode('exam'));setMode(appState.mode||'practice');

  // ---------- Transcript toggle ----------
  function setTranscripts(show){appState.transcripts=show;saveState();document.body.classList.toggle('show-transcripts',show);const b=$('#transcriptToggleBtn');if(b)b.textContent=`Transcripts: ${show?'on':'off'}`;}
  $('#transcriptToggleBtn')?.addEventListener('click',()=>setTranscripts(!document.body.classList.contains('show-transcripts')));
  setTranscripts(Boolean(appState.transcripts));

  // ---------- Progress ----------
  const sections=$$('[data-progress-section]');
  function updateProgress(){const done=sections.filter(s=>appState.completed?.includes(s.id)).length;const pct=Math.round(done/sections.length*100);$('#progressPercent').textContent=pct+'%';$('#progressBar').style.width=pct+'%';sections.forEach(s=>{$('.complete-btn',s)?.classList.toggle('done',appState.completed?.includes(s.id));if(appState.completed?.includes(s.id))$('.complete-btn',s).textContent='✓ Section complete';});}
  $$('.complete-btn').forEach(btn=>btn.addEventListener('click',()=>{const s=btn.closest('[data-progress-section]');appState.completed=appState.completed||[];if(!appState.completed.includes(s.id))appState.completed.push(s.id);saveState();updateProgress();toast('Section complete.');}));updateProgress();

  // ---------- Admin copy ----------
  $('#copyAdminLineBtn')?.addEventListener('click',async()=>{const gs=grammarLabScores();const gtotal=gs.reduce((s,x)=>s+x.correct,0);const priorities=gs.filter(x=>x.answered===x.total&&x.correct<2).map(x=>x.name).join(', ')||'none confirmed yet';const line=`Connect Learning | COURCELLE Mounia | Lesson 1 – Flight to B2 | Grammar diagnostic: ${gtotal}/${flatGrammarLab.length} | Grammar priorities: ${priorities} | Focus: ${$('#adminFocus').value.replace(/\n/g,' ')} | Strengths: ${$('#adminStrengths').value.replace(/\n/g,' ')} | Errors/Priorities: ${$('#adminErrors').value.replace(/\n/g,' ')} | Next: ${$('#adminNext').value.replace(/\n/g,' ')}`;try{await navigator.clipboard.writeText(line);$('#adminCopyFeedback').textContent='Copied.';toast('Tracking line copied.');}catch(e){$('#adminCopyFeedback').textContent=line;}});

  // ---------- Download results ----------
  $('#downloadResultsBtn')?.addEventListener('click',()=>{
    const score=(prefix,data)=>data.map((x,i)=>appState[`${prefix}-${i}`]===x.answer?1:0).reduce((a,b)=>a+b,0);
    const lines=[
      'Mounia — Flight to B2 | Lesson 1 Results','',
      `Date: ${new Date().toLocaleDateString()}`,
      `Progress: ${$('#progressPercent').textContent}`,
      `Stop translating: ${score('trans',translationQuestions)}/${translationQuestions.length}`,
      `Grammar precision: ${score('gram',grammarQuestions)}/${grammarQuestions.length}`,
      `B2 grammar diagnostic: ${grammarLabScores().reduce((s,x)=>s+x.correct,0)}/${flatGrammarLab.length}`,
      ...grammarLabScores().map(x=>`  - ${x.name}: ${x.correct}/${x.total} (${x.answered}/${x.total} answered)`),
      `Assistance scenario: ${score('assist',assistanceQuestions)}/${assistanceQuestions.length}`,
      '',
      `Baseline notes: ${$('#baselineNotes').value}`,
      `Chosen phrase 1: ${$('#phrase1').value}`,
      `Chosen phrase 2: ${$('#phrase2').value}`,
      `Chosen phrase 3: ${$('#phrase3').value}`,
      '',
      `Baggage response: ${$('#baggageResponse').value}`,
      `Assistance response: ${$('#assistanceResponse').value}`,
      `LILATE listening notes: ${$('#listenWrite').value}`,
      `LILATE writing: ${$('#lilateWriting').value}`,
      `Professional writing task: ${$('#writingTask').value}`,
      `Takeaway: ${$('#takeaway').value}`
    ];
    const blob=new Blob([lines.join('\n')],{type:'text/plain;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='Mounia_Lesson_1_Results.txt';a.click();URL.revokeObjectURL(a.href);
  });

  // ---------- Reset ----------
  $('#resetLessonBtn')?.addEventListener('click',()=>{if(confirm('Reset all saved answers and progress for this lesson?')){localStorage.removeItem(stateKey);location.reload();}});
})();
