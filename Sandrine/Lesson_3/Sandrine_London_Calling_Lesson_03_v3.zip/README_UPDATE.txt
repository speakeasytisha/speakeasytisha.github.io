Sandrine · London Calling — Lesson 03 · v3 (Explorer + Weather edition)

Files: index.html · styles.css (unchanged base) · lesson3.css · lesson3.js
Same storage key as before, so earlier progress is kept.

FIXES
- Checkpoints: the explanation appeared twice after answering (French note + help box). Now it appears once, in the feedback line.
- Listen buttons could play twice: now one single listener.
- Voice: picks an English (UK/US) voice, so iOS no longer reads with a French voice.
- Answer order is shuffled (the correct answer is no longer always in the same place).
- Content corrections: "We waited for 10 a.m." (actually possible) replaced; "Which sign means opposite?" reworded; "much time" in a positive sentence fixed; 16-year-olds pay adult Tube fares added.
- Royal Observatory: really closed since 2 Nov 2026 (phased reopening expected summer 2027) — flagged on its card, in the price table and in the planner.

NEW
- Explore: 📍 Map button on every card (map pop-up + "Route from our hotel"), area badge, "＋ Add to my list".
- 03 Weather talk: ask / describe / decide phrases, grammar (now vs general, going to / will / might, If it rains we'll…), weather words, match game, 10 checkpoints, 6 "What should we do today?" decisions, word order, 2 speaking tasks.
- 04 Two-week planner: 14-day practice forecast (tap to hear), activity bank (her list + easygoing extras), drag-and-drop OR tap-to-place calendar, move/swap, ⚡ energy per day, "Surprise twist" (rain / tired teens / sunshine), "Check my plan" with what-to-say sentences, plan-to-sentences generator, .ics export for her phone calendar.
- Directions: town-map game (8 missions — read the directions, tap the building).
- Tickets: arrival scene at Cutty Sark (doors open, family says "Wow!"), real price board (rmg.co.uk, checked 18 Nov 2026), family price calculator with her teenagers' ages, 9 price-detective questions, ticket-desk dialogue line by line.
- Inside: floor guide + wayfinding signs + QR code, drag-and-drop "where do we go?" match, UK/US match, 6 sign questions.
- Food: café menu game — lunch for four on a £45 budget (vegetarian, nut allergy, something hot), receipt, generated spoken order.
- 12 passport stamps (70% correct per section) + confetti on correct answers.

Note: the forecast is a simulation. Photos and the map need an internet connection.
