# Sylvain Bailly · Lesson 9A · Present Perfect Foundations

Single-page HTML/CSS/JS lesson designed before the broader Experience English & VTest Lab.

## Files
- index.html
- styles.css
- script.js
- README.md

## Features
- Present perfect rules: affirmative, negative, questions, short answers
- Same-subject tense mirror
- Keywords: ever, never, already, yet, just, recently, for, since
- Past simple vs present perfect contrast
- Been vs gone
- Professional and personal contexts
- Exercises from easy to harder
- Shuffled multiple-choice answers
- Hint buttons and immediate feedback
- Speaking and writing labs
- French help toggle
- Audio buttons via browser speech synthesis
- Qualiopi evaluation footer

## Editing
Edit `index.html` for text/content, `styles.css` for visual design, and `script.js` for interactions.
